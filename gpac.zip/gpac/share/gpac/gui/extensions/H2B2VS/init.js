
my_ext = {
    whoami: "GPAC-GUI-Extension-DISABLED",
    name: "",
    icon: "H2B2VS.png",
    author: "JeanLF",
    description: "H2B2VS Preferences",
    url: "http://h2b2vs.epfl.ch/",
    execjs: ["h2b2vs.js"],
    autostart: false,
    config_id: "H2B2VS",
    requires_gl: false,
    version_major: 1,
    version_minor: 0
};
